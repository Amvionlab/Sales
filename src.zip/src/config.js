// config.js
export const backendPort = 80;
export const baseURL = `${window.location.protocol}//${window.location.hostname}:${backendPort}/sales/`;
